// Package util contains commun util functions.
package util
