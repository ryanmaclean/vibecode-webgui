// Package app contains kubectl plugin logic.
package app
