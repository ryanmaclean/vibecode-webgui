// Package datadoghq containers all the WatermarkPodAutoscaler controller logic.
package datadoghq
